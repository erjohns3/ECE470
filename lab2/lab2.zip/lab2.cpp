//#include "rhino.h"
//#include <stdio.h>

#include <stdio.h>
#include <windows.h>
#include <wchar.h>
#include "rhino.h"
#include "labs.h"

/**
 * This starter file should help you do lab 2.
 *
 * Compile instructions:
 * click the green run button
 * 
 */

/**
 * This function just prints a sample banner when you start the program.
 * If you don't use this function, please have your program print a banner like it.
 */
void lab_banner()
{
	// Sample banner
	printf("Robotics Lab 2: The Tower of Hanoi\n");
	printf("Lab partners: Barney Rubble, Fred Flintstone\n");
}

/**
 * If you want, put a description of what your program does and how to use it in here.
 * (purely optional)
 */
void lab_help()
{
	printf("No instructions available.\n");
}

/**
 * Place your lab demo in this function.
 * When you run the program and type "lab", it will call this function.
 */
void lab_main()
{
	// Move the Rhino back home
	rhino_softhome();

	// Allocate a buffer for the user input
	char buffer[100];
	int count;

	// Read in some input - a simple user interface.
	int choice, wait=TRUE;
	while(wait)
	{
		buffer[0]='\0'; // clear the buffer

		printf("Enter a number between 1 and 3. ");
		fgets(buffer, 100, stdin);
		count=sscanf_s(buffer, "%d", &choice);

		if(count==0 || count==EOF)
		{
			printf("No number read; try again.\n");
			continue; // skip the rest of this loop
		}

		// validate the input
		if(1>choice || choice>3)
		{
			printf("%d is a bad number - try again.\n", choice);
		}
		else
		{
			// quit waiting for good input
			wait=FALSE;
		}
	}

	// use the input
	int i;
	for(i=0; i<choice; i++)
	{
		// Move the waist back and forth "choice" times.
		rhino_move('F', 200);
		rhino_move('F', -200);
	}

	// Move the Rhino back home
	rhino_softhome();

	// Go back to the main user interface
	return;
}

