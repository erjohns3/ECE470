/**
 * rhino.h
 * Copyright (C) 2003, Daniel Herring
 * Licensed under GPL version 2
*/

// Specify the desired character buffer size
#define BIG 200

void parseline(const char *);
